package entity;

import java.util.List;


public class College {

	
	private int college_id;
	private String college_name;
	
	
	private List<Department> departments;
 
	public College(String college_name) {
		super();
		this.college_name = college_name;
	}
	public College() {
		super();
	}
	public String getCollege_name() {
		return college_name;
	}

	public void setcollege_name(String college_name) {
		this.college_name = college_name;
	}

	public List<Department> getDepartments() {
		return departments;
	}

	public void setDepartments(List<Department> departments) {
		this.departments = departments;
	}

	@Override
	public String toString() {
		return "College [college_name=" + college_name + ", departments=" + departments + "]";
	}
	public int getCollege_id() {
		return college_id;
	}
	public void setCollege_id(int college_id) {
		this.college_id = college_id;
	}

	


}
