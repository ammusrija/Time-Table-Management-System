package entity;

import java.util.List;
import java.util.jar.Attributes.Name;

public class Course {

	private int Course_id;

	private String Course_name;

	private List<Semester> semester;
	
	public Course(String course_name, List<Semester> semester) {
	super();
	Course_name = course_name;
	this.semester = semester;
	}
	public String getCourse_name() {
		return Course_name;
	}

	public void setCourse_name(String course_name) {
		Course_name = course_name;
	}

	public List<Semester> getSemester() {
		return semester;
	}

	public void setSemester(List<Semester> semester) {
		this.semester = semester;
	}

	@Override
	public String toString() {
		return "Course [Course_name=" + Course_name + ", semester=" + semester + "]";
	}

}
