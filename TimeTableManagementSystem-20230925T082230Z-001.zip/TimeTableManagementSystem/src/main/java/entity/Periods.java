package entity;

import java.time.LocalDateTime;

public class Periods {
	
	private int period_id;
	private String periodName;
	private String periodFrom;
	private String periodTo;
	public Periods(String periodName, String periodFrom, String periodTo) {
		super();
		this.periodName = periodName;
		this.periodFrom = periodFrom;
		this.periodTo = periodTo;
	}
	public Periods() {
		super();
	}
	public int getPeriod_id() {
		return period_id;
	}
	public void setPeriod_id(int period_id) {
		this.period_id = period_id;
	}
	public String getPeriodName() {
		return periodName;
	}
	public void setPeriodName(String periodName) {
		this.periodName = periodName;
	}
	public String getPeriodFrom() {
		return periodFrom;
	}
	public void setPeriodFrom(String periodFrom) {
		this.periodFrom = periodFrom;
	}
	public String getPeriodTo() {
		return periodTo;
	}
	public void setPeriodTo(String periodTo) {
		this.periodTo = periodTo;
	}
	
	
}