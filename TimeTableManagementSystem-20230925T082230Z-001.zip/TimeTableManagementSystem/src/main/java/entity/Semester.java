package entity;

import java.util.List;


public class Semester {
	
	private int semester_id;
	
	private String semester_name;
	
	private List<Sections> sections;
	
	private List<Subjects> subjects;

	public Semester(String semester_name, List<Sections> sections, List<Subjects> subjects) {
		super();
		this.semester_name = semester_name;
		this.sections = sections;
		this.subjects = subjects;
	}

	public String getSemester_name() {
		return semester_name;
	}

	public List<Sections> getSections() {
		return sections;
	}

	public List<Subjects> getSubjects() {
		return subjects;
	}

	public void setSemester_name(String semester_name) {
		this.semester_name = semester_name;
	}

	public void setSections(List<Sections> sections) {
		this.sections = sections;
	}

	public void setSubjects(List<Subjects> subjects) {
		this.subjects = subjects;
	}

	@Override
	public String toString() {
		return "Semester [semester_name=" + semester_name + ", sections=" + sections + ", subjects=" + subjects + "]";
	}
	
	
	

}
