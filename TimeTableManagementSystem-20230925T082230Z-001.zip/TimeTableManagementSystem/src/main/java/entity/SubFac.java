package entity;

public class SubFac {
	
	private String Subject;
	
	private String Faculty;

	public SubFac(String subject, String faculty) {
		super();
		Subject = subject;
		Faculty = faculty;
	}

	public String getSubject() {
		return Subject;
	}

	public String getFaculty() {
		return Faculty;
	}

	public void setSubject(String subject) {
		Subject = subject;
	}

	public void setFaculty(String faculty) {
		Faculty = faculty;
	}
	
	
	

}
