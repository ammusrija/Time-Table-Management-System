package entity;

public class TimeTableDTO {
	private String week;
	
	private String Day;
	
	private String Period;
	
	private String subject;
	
	private String faculty;

	public TimeTableDTO(String day, String period, String subject, String faculty) {
		super();
		Day = day;
		Period = period;
		this.subject = subject;
		this.faculty = faculty;
	}
	

	public TimeTableDTO() {
		super();
	}


	public String getWeek() {
		return week;
	}

	public String getDay() {
		return Day;
	}

	public String getPeriod() {
		return Period;
	}

	public String getSubject() {
		return subject;
	}

	public String getFaculty() {
		return faculty;
	}

	public void setWeek(String week) {
		this.week = week;
	}

	public void setDay(String day) {
		Day = day;
	}

	public void setPeriod(String period) {
		Period = period;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}

	@Override
	public String toString() {
		return "TimeTableDTO [Day=" + Day + ", Period=" + Period + ", subject=" + subject
				+ ", faculty=" + faculty + "]";
	}
	
		
	}
