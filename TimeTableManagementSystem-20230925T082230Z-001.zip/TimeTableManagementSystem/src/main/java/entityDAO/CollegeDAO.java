package entityDAO;

import java.sql.Connection;
import java.util.List;

import entity.College;

public interface CollegeDAO {
	
	public void addCollege(String college_name,Connection con);
	public List<String> getCollege(Connection con);
	public void deleteCollege(Connection con, String collegeId);

}




