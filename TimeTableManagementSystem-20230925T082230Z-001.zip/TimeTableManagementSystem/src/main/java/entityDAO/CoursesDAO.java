package entityDAO;

import java.sql.Connection;
import java.util.List;

public interface CoursesDAO {
	public List<List<Object>> algoritham(Connection con,String deptName);

	void addCourse(Connection con,String dept, String coursename);

	void deletecourses(Connection con, int courseId);
	

}
