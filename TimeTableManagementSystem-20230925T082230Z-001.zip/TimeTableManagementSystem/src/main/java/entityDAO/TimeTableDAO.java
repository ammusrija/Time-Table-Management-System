package entityDAO;

public interface TimeTableDAO {

}
