package entityServices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import entityDAO.GeneratorDAO;
import entityDAO.ListDAO;
import entity.TimeTableDTO;

public class GeneratorServices implements GeneratorDAO {

	ListDAO ld = new ListServices();
	Map<String, String> subjectFacultyMap = new HashMap<>();
	List<String> sub = new ArrayList();
	int totalSubjects = 0;
	List<Object> entry = new ArrayList<>();
	Map<String, List<Object>> timetable = new HashMap<>();

	@Override
	public Map<String, List<Object>> algoritham(Connection con, String deptName, String courseName, String semId,
			String sectionId, int weeks, int days, int periods, List<String> dayList, List<String> perList) {
		try {

			String query = "SELECT subjectName, facultyName FROM subfacalot WHERE deptName=? AND courseName=? AND semId=? AND sectionId=?";
			PreparedStatement st = con.prepareStatement(query);
			st.setString(1, deptName);
			st.setString(2, courseName);
			st.setString(3, semId);
			st.setString(4, sectionId);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				String s = rs.getString("subjectName");
				String f = rs.getString("facultyname");
				subjectFacultyMap.put(s, f);
				sub.add(s);
			}
			totalSubjects = sub.size();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		String weekOfSemester = null;
		String subject = null;
		String dayOfWeek = null;
		String faculty = null;
		String periodLabel;
		for (int week = 0; week < weeks; week++) {
			entry.clear();
			weekOfSemester = "Week " + (week + 1);
			for (int period = 0; period < periods; period++) {
				periodLabel = perList.get(period);
				for (int day = 0; day < days; day++) {
					dayOfWeek = dayList.get(day);
					if (dayOfWeek.equalsIgnoreCase("SATURDAY") && periodLabel.equalsIgnoreCase("period5")) {
						break;
					} else {
						if (periodLabel.equalsIgnoreCase("period5")) {
							subject = "Break";
						} else {
							int subjectIndex = (week * day * period + day * period + period) % (totalSubjects);
							subject = sub.get(subjectIndex);
						}
						faculty = subjectFacultyMap.get(subject);
					}
					TimeTableDTO td = new TimeTableDTO(dayOfWeek, periodLabel, subject, faculty);
					entry.add(td);
				}
				timetable.put(weekOfSemester, entry);
			}
		}
		return timetable;

	}

}
