package entityServices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entityDAO.ListDAO;

public class ListServices implements ListDAO {
	
	public List<String> deptList(Connection con) {
		List<String> deptList = new ArrayList<>();
		try {
			String query = "SELECT * FROM department";
		 PreparedStatement st = con.prepareStatement(query);
		 ResultSet rs = st.executeQuery();
		 while (rs.next()) {
			 String s=rs.getString("deptname");
			 deptList.add(s);
	        }
	    } catch (SQLException e) {
	        
	        e.printStackTrace();
	    }
	    return deptList;
	}

	@Override
	public List<String> courList(Connection con) {
		
		List<String> courList = new ArrayList<>();
		try {
			String query = "SELECT * FROM course";
		 PreparedStatement st = con.prepareStatement(query);
		 ResultSet rs = st.executeQuery();
		 while (rs.next()) {
			 String s=rs.getString("courseName");
			 courList.add(s);
	        }
	    } catch (SQLException e) {
	        
	        e.printStackTrace();
	    }
	    return courList;
	}

	@Override
	public List<String> subList(Connection con) {
		List<String> subList = new ArrayList<>();
		try {
			String query = "SELECT * FROM subjects";
		 PreparedStatement st = con.prepareStatement(query);
		 ResultSet rs = st.executeQuery();
		 while (rs.next()) {
			 String s=rs.getString("subjectName");
			 subList.add(s);
	        }
	    } catch (SQLException e) {
	        
	        e.printStackTrace();
	    }
	    return subList;
	}

	@Override
	public List<String> facList(Connection con) {
		List<String> facList = new ArrayList<>();
		try {
			String query = "SELECT * FROM faculty";
		 PreparedStatement st = con.prepareStatement(query);
		 ResultSet rs = st.executeQuery();
		 while (rs.next()) {
			 String s=rs.getString("facultyname");
			 facList.add(s);
	        }
	    } catch (SQLException e) {
	        
	        e.printStackTrace();
	    }
	    return facList;
	}

	@Override
	public List<String> semList(Connection con) {
		List<String> semList = new ArrayList<>();
		try {
			String query = "SELECT * FROM semester";
		 PreparedStatement st = con.prepareStatement(query);
		 ResultSet rs = st.executeQuery();
		 while (rs.next()) {
			 String s=rs.getString("semName");
			 semList.add(s);
	        }
	    } catch (SQLException e) {
	        
	        e.printStackTrace();
	    }
	    return semList;
	}

	@Override
	public List<String> secList(Connection con) {
		List<String> secList = new ArrayList<>();
		try {
			String query = "SELECT * FROM sections";
		 PreparedStatement st = con.prepareStatement(query);
		 ResultSet rs = st.executeQuery();
		 while (rs.next()) {
			 String s=rs.getString("sectionName");
			 secList.add(s);
	        }
	    } catch (SQLException e) {
	        
	        e.printStackTrace();
	    }
	    return secList;
	}

	@Override
	public List<String> dayList(Connection con) {
		List<String> dayList = new ArrayList<>();
		try {
			String query = "SELECT * FROM days";
		 PreparedStatement st = con.prepareStatement(query);
		 ResultSet rs = st.executeQuery();
		 while (rs.next()) {
			 String s=rs.getString("daysname");
			 dayList.add(s);
	        }
	    } catch (SQLException e) {
	        
	        e.printStackTrace();
	    }
	    return dayList;
	}

	@Override
	public List<String> perList(Connection con) {
		List<String> perList = new ArrayList<>();
		try {
			String query = "SELECT * FROM periods";
		 PreparedStatement st = con.prepareStatement(query);
		 ResultSet rs = st.executeQuery();
		 while (rs.next()) {
			 String s=rs.getString("periodName");
			 perList.add(s);
	        }
	    } catch (SQLException e) {
	        
	        e.printStackTrace();
	    }
	    return perList;
	}

}
