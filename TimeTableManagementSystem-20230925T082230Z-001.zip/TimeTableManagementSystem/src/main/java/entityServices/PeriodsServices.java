package entityServices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entityDAO.CoursesDAO;
import entityDAO.PeriodsDAO;

public class PeriodsServices implements PeriodsDAO{

	@Override
	public void addPeriod(String periodName, String periodfrom, String periodTo, Connection con) {
		try {
		String query = "INSERT INTO periods(periodName,periodfrom,periodTo)VALUES (?, ?,?)";
        PreparedStatement st = con.prepareStatement(query);
        st.setString(1, periodName);
		st.setString(2, periodfrom);
		st.setString(3, periodTo);
		st.executeUpdate();
		}catch (SQLException e) {
			System.out.println("unable to connect with database");
		}

	}

	@Override
	public List<String> getPeriod(Connection con) {
   	 List<String> PeriodList = new ArrayList<>();
		try {
			String query = "SELECT periodName,periodfrom,periodTo FROM periods";
		 PreparedStatement st = con.prepareStatement(query);
		 ResultSet rs = st.executeQuery();
		 while (rs.next()) {
			 String s=rs.getString("periodName");
			 PeriodList.add(s);
	            String s1=rs.getString("periodfrom");
	            PeriodList.add(s1);
	            String s2=rs.getString("periodTo");
	            PeriodList.add(s2);
	        }
	    } catch (SQLException e) {
	        
	        e.printStackTrace();
	    }
		return PeriodList;
	}

	@Override
	public void updatePeriod(String periodName, String periodFrom, String periodTo, Connection con) {
		 try {
		        String query = "UPDATE periods SET periodName = ?, periodfrom = ?, periodTo = ? WHERE periodId = ?";
		        PreparedStatement st = con.prepareStatement(query);
		        st.setString(1, periodName);
		        st.setString(2, periodFrom);
		        st.setString(3, periodTo);
		       
		        st.executeUpdate();
		    } catch (SQLException e) {
		        System.out.println("Unable to update period: " + e.getMessage());
		    }
		}

	@Override
	public void deletePeriod(Connection con, String periodId) {
		try {
			String query = "DELETE FROM periods WHERE periodName = ?";
		 PreparedStatement st = con.prepareStatement(query);
			st.setString(1, periodId);
			 st.executeUpdate();
		}catch (SQLException e) {
			System.out.println("unable to connect with database");
		}
	}
		
	
}