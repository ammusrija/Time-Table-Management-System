package entityServices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import entityDAO.CoursesDAO;
import entityDAO.ListDAO;
import entityDAO.SubjectsDAO;

public class SubjectsServices implements SubjectsDAO {

	Map<String, String> subjectsemesterMap = new HashMap<>();

	List<List<Object>> assign = new ArrayList<>();

	@Override
	public List<List<Object>> algoritham(Connection con, String deptName, String courseName, String semId) {
		try {

			String query = "SELECT * FROM subjects WHERE deptName=? AND courseName=? AND semId=?";
			PreparedStatement st = con.prepareStatement(query);
			st.setString(1, deptName);
			st.setString(2, courseName);
			st.setString(3, semId);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				int i = rs.getInt("sno");
				String s = rs.getString("subjectName");
				String f = rs.getString("semId");
				List<Object> entry = Arrays.asList(i, s, f);
				assign.add(entry);
			}
		} catch (SQLException e) {
			e.printStackTrace();

		}
		return assign;

	}

	@Override
	public void addSubjects(Connection con, String deptName, String courseName, String semId, String sub) {
		try {
			String query = "INSERT INTO subjects (deptName,courseName, semId, subjectName) VALUES (?,?,?,?)";
			PreparedStatement st = con.prepareStatement(query);
			st.setString(1, deptName);
			st.setString(2, courseName);
			st.setString(3, semId);
			st.setString(4, sub);
			st.executeUpdate();
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void deleteSubject(Connection con, int subId) {
		try {
			String query = "DELETE FROM subjects WHERE sno = ?";
			PreparedStatement st = con.prepareStatement(query);
			st.setInt(1, subId);
			st.executeUpdate();
		} catch (SQLException e) {
			System.out.println("unable to connect with database");
		}

	}

	@Override
	public void editSubject(Connection con, int subId, String SubjectName) {
		try {

			String query = "UPDATE subjects SET subjectName = ? WHERE sno = ?";
			PreparedStatement st = con.prepareStatement(query);
			st.setInt(1, subId);
			st.setString(2, SubjectName);

			st.executeUpdate();
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}