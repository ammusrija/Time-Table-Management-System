package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entityDAO.CoursesDAO;
import entityDAO.DepartmentDAO;
import entityDAO.ListDAO;
import entityServices.ConnectionServices;
import entityServices.CoursesServices;
import entityServices.DepartmentServices;
import entityServices.ListServices;

@WebServlet("/CoursesDelServlet")
public class CoursesDelServlet extends HttpServlet {
	DepartmentDAO de=new DepartmentServices();
	CoursesDAO g = new CoursesServices();
	ListDAO cr = new ListServices();
	List<List<Object>> cour;
	String dept;
	Connection con = null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");

		ConnectionServices c = new ConnectionServices();
		Connection con = c.Con();
		int courid = Integer.parseInt(request.getParameter("id"));
		g.deletecourses(con, courid);
		 List<String> deptList = cr.deptList(con);
		  request.setAttribute("deptList", deptList);
		  dept = request.getParameter("dept");
		  cour=g.algoritham(con, dept);
	      request.setAttribute("courList", cour);
		  request.getRequestDispatcher("course.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
