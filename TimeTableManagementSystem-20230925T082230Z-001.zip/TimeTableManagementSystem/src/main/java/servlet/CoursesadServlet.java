package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entityDAO.CoursesDAO;
import entityDAO.DepartmentDAO;
import entityDAO.ListDAO;
import entityDAO.SubFacDAO;
import entityServices.ConnectionServices;
import entityServices.CoursesServices;
import entityServices.DepartmentServices;
import entityServices.ListServices;
import entityServices.SubFacServices;

@WebServlet("/CoursesadServlet")
public class CoursesadServlet extends HttpServlet {
	DepartmentDAO de=new DepartmentServices();
	CoursesDAO g = new CoursesServices();
	ListDAO cr = new ListServices();
	Connection con = null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");

		ConnectionServices c = new ConnectionServices();
		Connection con = c.Con();
		
		List<String> deptList = cr.deptList(con);
        request.setAttribute("deptList", deptList);
        request.getRequestDispatcher("coursead.jsp").forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
        
		String dept = request.getParameter("dept");
		String cour = request.getParameter("cour");
		g.addCourse(con, dept, cour);
		
	}
}