package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entityDAO.CollegeDAO;
import entityDAO.DepartmentDAO;
import entityServices.CollegeServices;
import entityServices.ConnectionServices;
import entityServices.DepartmentServices;

@WebServlet("/DepartmentServlet")
public class DepartmentServlet extends HttpServlet {
	DepartmentDAO de = new DepartmentServices();
	CollegeDAO cd = new CollegeServices();
	Connection con;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");

		ConnectionServices c = new ConnectionServices();
		con = c.Con();
		String deptId = request.getParameter("id");
		de.deleteDept(con, deptId);
		List<String> collegeList = cd.getCollege(con);
		request.setAttribute("collegeList", collegeList);
		List<String> deptList = de.getDepartment(con);
		request.setAttribute("deptList", deptList);

		request.getRequestDispatcher("department.jsp").forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String deptname = request.getParameter("name");
		de.addDepartment(deptname, con);
	}

}
