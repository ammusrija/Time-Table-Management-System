package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import entityDAO.GeneratorDAO;
import entityDAO.ListDAO;
import entityServices.ConnectionServices;
import entityServices.GeneratorServices;
import entityServices.ListServices;

@WebServlet("/GeneratorServlet")
public class GeneratorServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		ConnectionServices c = new ConnectionServices();
		Connection con = c.Con();
		String method = request.getParameter("method");
		if ("doRest".equals(method)) {
			doRest(request, response);
		}
		ListDAO cr = new ListServices();
		List<String> deptList = cr.deptList(con);
		List<String> courList = cr.courList(con);
		List<String> semList = cr.semList(con);
		List<String> secList = cr.secList(con);
		List<String> dayList = cr.dayList(con);
		List<String> perList = cr.perList(con);
		request.setAttribute("deptList", deptList);
		request.setAttribute("courList", courList);
		request.setAttribute("semList", semList);
		request.setAttribute("secList", secList);
		request.setAttribute("perList", perList);
		request.setAttribute("dayList", dayList);
		request.getRequestDispatcher("generator.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		ListDAO cr = new ListServices();
		ConnectionServices c = new ConnectionServices();
		Connection con = c.Con();
		List<String> deptList = cr.deptList(con);
		List<String> courList = cr.courList(con);
		List<String> semList = cr.semList(con);
		List<String> secList = cr.secList(con);
		List<String> dayList = cr.dayList(con);
		List<String> perList = cr.perList(con);

		String dept = request.getParameter("dept1");
		String cour = request.getParameter("cour1");
		String sem = request.getParameter("sem1");
		String sec = request.getParameter("sec1");
		int weeks = Integer.parseInt(request.getParameter("weeks1"));
		String week = request.getParameter("week");
		if (week != null) {
			week = "Week " + week;
		}
		GeneratorDAO g = new GeneratorServices();
		Map<String, List<Object>> timeTable = g.algoritham(con, dept, cour, sem, sec, weeks, dayList.size(),
				perList.size(), dayList, perList);
		HttpSession session = request.getSession();
		session.setAttribute("timeTable1", timeTable);
		List<Object> weekTimeTable = timeTable.get(week);
		request.setAttribute("subList", weekTimeTable);
		request.setAttribute("deptList", deptList);
		request.setAttribute("courList", courList);
		request.setAttribute("semList", semList);
		request.setAttribute("secList", secList);
		request.setAttribute("perList", perList);
		request.setAttribute("dayList", dayList);
		request.getRequestDispatcher("generator.jsp").forward(request, response);
	}

	protected void doRest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String weekParameter = request.getParameter("week");
		int currentWeek = Integer.parseInt(weekParameter);
		request.setAttribute("week", currentWeek);
		if (weekParameter != null) {
			weekParameter = "Week " + currentWeek;
		}
		HttpSession session = request.getSession();
			Map<String, List<Object>> timeTablenext = (Map<String, List<Object>>) session.getAttribute("timeTable1");
			List<Object> weekTimeTable1 = timeTablenext.get(weekParameter);
			request.setAttribute("subList", weekTimeTable1);
		}

	}
