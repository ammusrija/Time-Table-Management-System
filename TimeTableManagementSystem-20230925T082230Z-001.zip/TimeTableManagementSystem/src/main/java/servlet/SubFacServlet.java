package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entityDAO.GeneratorDAO;
import entityDAO.ListDAO;
import entityDAO.SubFacDAO;
import entityServices.ConnectionServices;
import entityServices.GeneratorServices;
import entityServices.ListServices;
import entityServices.SubFacServices;

@WebServlet("/SubFacServlet")
public class SubFacServlet extends HttpServlet {
	SubFacDAO g = new SubFacServices();
	ListDAO cr = new ListServices();
	List<List<Object>> sub;
	
	Connection con;
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");

		ConnectionServices c = new ConnectionServices();
		con = c.Con();
		String method = request.getParameter("method");
		if ("doDelete".equals(method)) {
			doDelete(request, response);
		}
		List<String> deptList = cr.deptList(con);
        List<String> courList = cr.courList(con);
        List<String> semList = cr.semList(con);
        List<String> secList = cr.secList(con);
        request.setAttribute("deptList", deptList);
        request.setAttribute("courList", courList);
        request.setAttribute("semList", semList);
        request.setAttribute("secList", secList);
        request.getRequestDispatcher("subfac.jsp").forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		List<String> deptList = cr.deptList(con);
        List<String> courList = cr.courList(con);
        List<String> semList = cr.semList(con);
        List<String> secList = cr.secList(con);
        
        String dept = request.getParameter("dept1");
        String cour = request.getParameter("cour1");
        String sem = request.getParameter("sem1");
        String sec = request.getParameter("sec1");
		sub=g.algoritham(con, dept, cour, sem, sec);
		request.setAttribute("subList", sub);
        request.setAttribute("deptList", deptList);
        request.setAttribute("courList", courList);
        request.setAttribute("semList", semList);
        request.setAttribute("secList", secList);
		request.getRequestDispatcher("subfac.jsp").forward(request, response);
		sub.clear();
	}
	
	protected void doDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		int SubFacId = Integer.parseInt(request.getParameter("id"));
		g.deleteSubFac(con, SubFacId);
		
	}
	
	
	
}
